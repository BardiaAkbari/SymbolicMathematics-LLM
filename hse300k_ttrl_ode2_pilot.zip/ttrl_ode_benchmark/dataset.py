from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Tuple


def _pick_key(keys, candidates):
    low = {str(k).strip().lower(): k for k in keys}
    for c in candidates:
        if c in low:
            return low[c]
    return None


def iter_dataset_rows(root: str):
    """Yield rows from CSV/JSONL files under the HSE repo, auto-detecting schema."""
    rootp = Path(root)
    if not rootp.exists():
        raise FileNotFoundError(root)
    files = sorted([p for p in rootp.rglob('*') if p.is_file() and p.suffix.lower() in {'.csv','.jsonl','.json'}])
    if not files:
        raise RuntimeError(f"No CSV/JSON/JSONL files found under {root}")

    for path in files:
        rel = str(path.relative_to(rootp))
        try:
            if path.suffix.lower() == '.csv':
                with path.open('r', encoding='utf-8-sig', errors='replace', newline='') as f:
                    rdr = csv.DictReader(f)
                    if not rdr.fieldnames:
                        continue
                    eqk = _pick_key(rdr.fieldnames, ['equation','ode','input','problem','question'])
                    ank = _pick_key(rdr.fieldnames, ['answer','solution','target','output'])
                    typek = _pick_key(rdr.fieldnames, ['type','class','category','equation_type'])
                    if not eqk or not ank:
                        continue
                    for i,row in enumerate(rdr):
                        yield {
                            'source_file': rel, 'source_row': i+2,
                            'equation_latex': row.get(eqk,''), 'answer_latex': row.get(ank,''),
                            'category': row.get(typek,'') if typek else '',
                        }
            elif path.suffix.lower() == '.jsonl':
                with path.open('r',encoding='utf-8',errors='replace') as f:
                    for i,line in enumerate(f):
                        try: row=json.loads(line)
                        except Exception: continue
                        if not isinstance(row,dict): continue
                        eqk=_pick_key(row.keys(), ['equation','ode','input','problem','question'])
                        ank=_pick_key(row.keys(), ['answer','solution','target','output'])
                        typek=_pick_key(row.keys(), ['type','class','category','equation_type'])
                        if not eqk or not ank: continue
                        yield {'source_file':rel,'source_row':i+1,'equation_latex':row.get(eqk,''),
                               'answer_latex':row.get(ank,''),'category':row.get(typek,'') if typek else ''}
            else:
                with path.open('r',encoding='utf-8',errors='replace') as f:
                    obj=json.load(f)
                rows=obj if isinstance(obj,list) else obj.get('data',[]) if isinstance(obj,dict) else []
                for i,row in enumerate(rows):
                    if not isinstance(row,dict): continue
                    eqk=_pick_key(row.keys(), ['equation','ode','input','problem','question'])
                    ank=_pick_key(row.keys(), ['answer','solution','target','output'])
                    typek=_pick_key(row.keys(), ['type','class','category','equation_type'])
                    if not eqk or not ank: continue
                    yield {'source_file':rel,'source_row':i+1,'equation_latex':row.get(eqk,''),
                           'answer_latex':row.get(ank,''),'category':row.get(typek,'') if typek else ''}
        except Exception as e:
            print(f"[warn] skipped {rel}: {type(e).__name__}: {e}")
