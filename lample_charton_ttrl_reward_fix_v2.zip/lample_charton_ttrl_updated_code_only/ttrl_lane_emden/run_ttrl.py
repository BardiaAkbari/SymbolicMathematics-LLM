#!/usr/bin/env python3
import argparse
import copy
import json
import os
import random
import sys

import numpy as np
import torch

# Allow running as `python ttrl_lane_emden/run_ttrl.py` from repo root.
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from ttrl_lane_emden.core import (
    configure_trainable,
    equation_to_tokens,
    evaluate_rollout_batch,
    load_pretrained,
    make_problem,
    sample_rollouts,
    sequence_logprobs,
    summarize_infos,
)


def parse_args():
    p = argparse.ArgumentParser(description="Verifier-guided test-time RL for Lample--Charton ODE2")
    p.add_argument("--checkpoint", required=True, help="Path to official ode2.pth")
    p.add_argument("--problem", choices=["harmonic", "lane_emden"], default="lane_emden")
    p.add_argument("--n", type=int, default=1, help="Lane--Emden index")
    p.add_argument("--lane-form", choices=["standard", "cleared"], default="cleared", help="Use x*y'' + 2*y' + x*y^n = 0 by default")
    p.add_argument("--steps", type=int, default=20)
    p.add_argument("--rollouts", type=int, default=32)
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--max-len", type=int, default=128)
    p.add_argument("--lr", type=float, default=3e-6)
    p.add_argument("--scope", choices=["proj", "last_layer", "decoder"], default="last_layer")
    p.add_argument("--grad-clip", type=float, default=1.0)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--cpu", action="store_true")
    p.add_argument("--save-jsonl", default="ttrl_lane_emden_results.jsonl")
    p.add_argument("--length-normalize", action=argparse.BooleanOptionalAction, default=True)
    return p.parse_args()


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def print_top(rows):
    for r in rows:
        print(
            f"  idx={r['idx']:>2} reward={r['reward']:>8.3f} relres={r['mse']:.3e} "
            f"rank={r['rank']} res0={int(r['res0'])} gen={int(r['verified_general'])} :: {r['expr']}"
        )


def greedy_decode(env, encoder, decoder, problem, device, max_len):
    toks, generated, glen = sample_rollouts(
        env, encoder, decoder, problem.equation,
        n_samples=1, temperature=None, max_len=max_len, device=device
    )
    candidates, infos = evaluate_rollout_batch(env, problem, generated, glen)
    return candidates[0], infos[0]


def main():
    args = parse_args()
    seed_all(args.seed)
    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    print(f"device={device}")

    env, encoder, decoder, params, ckpt = load_pretrained(args.checkpoint, device)
    problem = make_problem(env, args.problem, n=args.n, mode="general", lane_form=args.lane_form)
    src_tokens = equation_to_tokens(env, problem.equation)
    print(f"problem={problem.name}")
    print(f"equation={problem.equation}")
    print(f"input_prefix={' '.join(src_tokens)}")
    print(f"expected_reference={problem.expected}")
    print(f"checkpoint_arch emb={params.emb_dim} enc={params.n_enc_layers} dec={params.n_dec_layers} heads={params.n_heads}")

    for p in encoder.parameters():
        p.requires_grad_(False)
    trainable = configure_trainable(decoder, args.scope)
    print(f"trainable_parameters={sum(p.numel() for p in trainable):,} scope={args.scope}")
    optimizer = torch.optim.Adam(trainable, lr=args.lr)

    base_decoder_state = copy.deepcopy(decoder.state_dict())

    print("\n[baseline greedy]")
    (_, words), info = greedy_decode(env, encoder, decoder, problem, device, args.max_len)
    print(f"reward={info.reward:.3f} rank={info.generality_rank} residual_zero={info.exact_residual_zero}")
    print(f"expr={info.expression}")

    # Encoder representation never changes in this first POC.
    from ttrl_lane_emden.core import encode_tokens
    x, src_len_1 = encode_tokens(env, src_tokens, device)
    with torch.no_grad():
        enc1 = encoder("fwd", x=x, lengths=src_len_1, causal=False).transpose(0, 1)

    fout = open(args.save_jsonl, "w", encoding="utf-8")
    solved = False

    for step in range(args.steps):
        decoder.eval()
        with torch.no_grad():
            enc_k = enc1.expand(args.rollouts, -1, -1).contiguous()
            src_len = src_len_1.expand(args.rollouts).contiguous()
            generated, gen_len = decoder.generate(
                enc_k, src_len, max_len=args.max_len, sample_temperature=args.temperature
            )

        candidates, infos = evaluate_rollout_batch(env, problem, generated, gen_len)
        rewards_np = np.array([z.reward for z in infos], dtype=np.float32)
        full_success = [z.exact_residual_zero and z.verified_general for z in infos]
        top = summarize_infos(candidates, infos, top_k=5)
        print(f"\n[step {step:02d}] reward mean={rewards_np.mean():.3f} std={rewards_np.std():.3f} max={rewards_np.max():.3f} successes={sum(full_success)}")
        print_top(top)

        row = {
            "step": step,
            "reward_mean": float(rewards_np.mean()),
            "reward_std": float(rewards_np.std()),
            "reward_max": float(rewards_np.max()),
            "n_success": int(sum(full_success)),
            "top": top,
        }
        fout.write(json.dumps(row) + "\n")
        fout.flush()

        # Do not stop immediately: seeing whether greedy changes is the stronger TTRL result.
        rewards = torch.tensor(rewards_np, device=device)
        if float(rewards.std(unbiased=False).item()) < 1e-8:
            print("  all rewards equal; skipping update")
            continue
        advantages = (rewards - rewards.mean()) / (rewards.std(unbiased=False) + 1e-6)

        # Recompute trajectory log-probabilities with gradients.
        decoder.train()
        enc_k = enc1.detach().expand(args.rollouts, -1, -1).contiguous()
        src_len = src_len_1.expand(args.rollouts).contiguous()
        seq_lp = sequence_logprobs(
            decoder, enc_k, src_len, generated, gen_len,
            length_normalize=args.length_normalize,
        )
        loss = -(advantages.detach() * seq_lp).mean()

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(trainable, args.grad_clip)
        optimizer.step()
        decoder.eval()
        print(f"  policy_loss={loss.item():.6f}")

        (_, _), ginfo = greedy_decode(env, encoder, decoder, problem, device, args.max_len)
        print(f"  adapted_greedy reward={ginfo.reward:.3f} rank={ginfo.generality_rank} res0={int(ginfo.exact_residual_zero)} :: {ginfo.expression}")
        if ginfo.exact_residual_zero and ginfo.verified_general:
            print("  *** GREEDY POLICY NOW PRODUCES A VERIFIED GENERAL SOLUTION ***")
            solved = True
            break

    fout.close()
    print("\n[final greedy]")
    (_, _), final_info = greedy_decode(env, encoder, decoder, problem, device, args.max_len)
    print(f"reward={final_info.reward:.3f} rank={final_info.generality_rank} residual_zero={final_info.exact_residual_zero}")
    print(f"expr={final_info.expression}")
    print(f"result_log={args.save_jsonl}")


if __name__ == "__main__":
    main()
