from __future__ import annotations

import signal
from contextlib import contextmanager
from typing import Optional, Sequence

from ttrl_lane_emden.core import (
    Problem, RewardInfo, generated_to_candidates, ids_to_sympy, score_general_candidate,
)


class CandidateVerificationTimeout(BaseException):
    pass


@contextmanager
def candidate_time_limit(seconds: float):
    seconds = float(seconds or 0.0)
    if seconds <= 0 or not hasattr(signal, 'setitimer'):
        yield
        return
    def _handler(signum, frame):
        raise CandidateVerificationTimeout(f"candidate verification exceeded {seconds:g}s")
    old = signal.getsignal(signal.SIGALRM)
    signal.signal(signal.SIGALRM, _handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, old)


def timeout_info(error: str, expression=None):
    return RewardInfo(
        reward=-25.0, valid_parse=False, exact_residual_zero=False,
        generality_rank=0, numerical_mse=1e12, expression=expression,
        residual=None, verified_general=False, error=error,
    )


class ExactODEVerifier:
    """Exact residual + generality verifier with per-candidate timeout."""
    def __init__(self, env, problem: Problem, candidate_timeout_s: float = 4.0):
        self.env = env
        self.problem = problem
        self.candidate_timeout_s = float(candidate_timeout_s)

    def score_ids(self, token_ids: Sequence[int]) -> RewardInfo:
        hyp = None
        try:
            with candidate_time_limit(self.candidate_timeout_s):
                hyp = ids_to_sympy(self.env, token_ids)
                return score_general_candidate(self.env, self.problem, hyp)
        except CandidateVerificationTimeout as e:
            return timeout_info(f"TIMEOUT: {e}", hyp)
        except BaseException as e:
            return timeout_info(f"{type(e).__name__}: {e}", hyp)

    def evaluate_generated(self, generated, gen_len, cache: Optional[dict] = None):
        candidates = generated_to_candidates(self.env, generated, gen_len)
        infos = []
        hits = misses = 0
        for ids, _ in candidates:
            key = tuple(int(x) for x in ids)
            if cache is not None and key in cache:
                z = cache[key]; hits += 1
            else:
                z = self.score_ids(ids); misses += 1
                if cache is not None:
                    cache[key] = z
            infos.append(z)
        return candidates, infos, hits, misses


def exact_count(infos):
    return int(sum(bool(z.verified_general) for z in infos))


def timeout_count(infos):
    return int(sum(bool(z.error and str(z.error).startswith('TIMEOUT:')) for z in infos))
